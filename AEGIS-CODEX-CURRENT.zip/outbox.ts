import { API_BASE, type CreateReportRequest, type SharedReport } from './api';

export type Receipt = { report?: SharedReport; tracking_token: string; id?: string; status: string };
export type Queued = { id: string; path: '/reports' | '/distress'; payload: Record<string, unknown>;
  created: string; state: 'pending' | 'sent' | 'review'; attempts: number; next: number; receipt?: Receipt; message?: string };
const changed = () => window.dispatchEvent(new Event('aegis-outbox'));
export function openStore(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('aegis-outbox', 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore('queue', { keyPath: 'id' });
      request.result.createObjectStore('drafts');
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error('This browser could not save the report. Keep this page open and try again.'));
  });
}
export async function store<T>(name: string, mode: IDBTransactionMode, action: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openStore();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(name, mode);
    const request = action(transaction.objectStore(name));
    transaction.oncomplete = () => { db.close(); resolve(request.result); };
    transaction.onerror = transaction.onabort = () => { db.close(); reject(new Error('Saving failed. Keep this page open and retry.')); };
  });
}
export const listOutbox = () => store<Queued[]>('queue', 'readonly', s => s.getAll());
export function rememberReceipt(receipt: Receipt) {
  const id = receipt.report?.id || receipt.id;
  if (id && receipt.tracking_token) localStorage.setItem('aegis-receipt-' + id, receipt.tracking_token);
}
let running: Promise<void> | undefined;
export function syncOutbox(force = false): Promise<void> {
  if (running) return running;
  running = (async () => {
    if (!navigator.onLine) return;
    for (const item of await listOutbox()) {
      if (item.state !== 'pending' || (!force && item.next > Date.now())) continue;
      try {
        const response = await fetch(API_BASE + item.path, { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(item.payload), signal: AbortSignal.timeout(15000) });
        if (!response.ok) {
          if ([400, 409, 413, 415, 422].includes(response.status)) {
            item.state = 'review'; item.message = 'Delivery needs review. Your original report remains saved here.';
          } else throw new Error('retry');
        } else {
          const receipt: Receipt = await response.json();
          if (!receipt.tracking_token || !(receipt.report?.id || receipt.id)) throw new Error('receipt');
          item.receipt = receipt; item.state = 'sent';
          rememberReceipt(receipt);
        }
      } catch {
        item.attempts++; item.next = Date.now() + Math.min(300000, 3000 * 2 ** Math.min(item.attempts, 7));
        item.message = 'Saved on this device. Delivery is not confirmed yet.';
      }
      await store('queue', 'readwrite', s => s.put(item)); changed();
    }
  })().finally(() => { running = undefined; });
  return running;
}
export async function enqueue(path: Queued['path'], payload: Record<string, unknown>, id = crypto.randomUUID()) {
  const item: Queued = { id, path, payload: { ...payload, client_request_id: id }, created: new Date().toISOString(), state: 'pending', attempts: 0, next: 0 };
  await store('queue', 'readwrite', s => s.put(item));
  changed();
  if (navigator.storage?.persist) void navigator.storage.persist().catch(() => false);
  if ('serviceWorker' in navigator) {
    void navigator.serviceWorker.ready.then(registration => {
      const sync = (registration as ServiceWorkerRegistration & { sync?: { register(tag: string): Promise<void> } }).sync;
      return sync?.register('aegis-outbox');
    }).catch(() => {});
  }
  // Saving is immediate; a slow network must not trap the user in a sending screen.
  void syncOutbox();
  return id;
}
export const queueReport = (report: CreateReportRequest) => enqueue('/reports', { ...report });
export async function saveVoiceDraft(audio: Blob) { await store('drafts', 'readwrite', s => s.put(audio, 'voice')); }
export const loadVoiceDraft = () => store<Blob | undefined>('drafts', 'readonly', s => s.get('voice'));
export async function encodeBlob(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(',')[1]);
    reader.onerror = reject; reader.readAsDataURL(blob);
  });
}
