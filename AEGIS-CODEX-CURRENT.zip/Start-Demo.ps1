# One command, project-contained files, independent browser sessions for staff roles.
$ErrorActionPreference = 'Stop'
$demoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if ($demoRoot -ne 'C:\Users\DELL\OneDrive\Desktop\AEGIS-MAIN') { throw 'Unexpected project root.' }
Set-Location -LiteralPath $demoRoot
foreach ($part in @('.cache\tmp', '.cache\npm', '.cache\demo')) { New-Item -ItemType Directory -Path (Join-Path $demoRoot $part) -Force | Out-Null }
$env:TEMP = Join-Path $demoRoot '.cache\tmp'
$env:TMP = $env:TEMP
$env:npm_config_cache = Join-Path $demoRoot '.cache\npm'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:AEGIS_BACKEND_URL = 'http://127.0.0.1:8001'
$env:AEGIS_DB_PATH = '.cache/demo/session-' + [guid]::NewGuid().ToString('N') + '.sqlite'
$env:AEGIS_COMMAND_USERNAME = 'demo-command'
$env:AEGIS_COMMAND_PASSWORD = 'AEGIS-demo-only'
$env:AEGIS_COMMAND_AUTH_SECRET = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')
$demoAccounts = @{}
Get-Content -LiteralPath (Join-Path $demoRoot 'data\resources.json') -Raw | ConvertFrom-Json | ForEach-Object { $demoAccounts[$_.id] = 'AEGIS-demo-only' }
$env:AEGIS_RESPONDER_ACCOUNTS = $demoAccounts | ConvertTo-Json -Compress
$env:AEGIS_ENABLE_RESET = 'false'
# In this local demo, no real emergency gateway exists. Provider keys remain backend-only.
$backendProcess = $null
$frontendProcess = $null
try {
    & npm.cmd --prefix frontend run build
    if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed.' }
    $backendProcess = Start-Process -FilePath (Join-Path $demoRoot 'backend\.venv\Scripts\python.exe') -ArgumentList '-B -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8001' -WorkingDirectory $demoRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $demoRoot '.cache\demo\backend.log') -RedirectStandardError (Join-Path $demoRoot '.cache\demo\backend-error.log')
    $frontendProcess = Start-Process -FilePath 'node.exe' -ArgumentList 'node_modules/vite/bin/vite.js preview --host 127.0.0.1 --port 5173 --strictPort' -WorkingDirectory (Join-Path $demoRoot 'frontend') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $demoRoot '.cache\demo\frontend.log') -RedirectStandardError (Join-Path $demoRoot '.cache\demo\frontend-error.log')
    Write-Host 'Citizen: http://127.0.0.1:5173/report'
    Write-Host 'Command: http://127.0.0.1:5173/command | demo-command / AEGIS-demo-only'
    Write-Host 'Responder: http://127.0.0.1:5173/responder | assigned resource ID / AEGIS-demo-only'
    Write-Host 'Use separate browser profiles for citizen, Command and responder. All missions are simulated.'
    Write-Host 'Press Ctrl+C to stop these demo processes. Each launch uses a fresh project-local database.'
    while (-not $backendProcess.HasExited -and -not $frontendProcess.HasExited) { Start-Sleep -Seconds 1 }
    throw 'A demo process stopped. Inspect .cache/demo logs; another process may already use the port.'
} finally {
    foreach ($demoProcess in @($backendProcess, $frontendProcess)) {
        if ($null -ne $demoProcess -and -not $demoProcess.HasExited) { Stop-Process -Id $demoProcess.Id }
    }
}
