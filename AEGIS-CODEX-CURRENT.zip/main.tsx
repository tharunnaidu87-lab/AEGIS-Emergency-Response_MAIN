import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import "./commandAuthFetch";
import App from "./App";
import { OutboxStatus } from "./DeliveryUI";
import "./resilience.css";
import CommandAuthBoundary from "./CommandAuthBoundary";
import ErrorBoundary from "./ErrorBoundary";

const root = document.getElementById("root");
if (!root) throw new Error("AEGIS root element was not found.");

createRoot(root).render(
  <StrictMode>
    <ErrorBoundary>
      <OutboxStatus />
      <CommandAuthBoundary>
        <App />
      </CommandAuthBoundary>
    </ErrorBoundary>
  </StrictMode>,
);

if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  void navigator.serviceWorker.register('/sw.js').catch(() => { /* Outbox remains usable without shell caching. */ });
}
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    void navigator.serviceWorker.register("/sw.js").catch(() => {
      // Online operation remains available if service-worker registration fails.
    });
  });
}
